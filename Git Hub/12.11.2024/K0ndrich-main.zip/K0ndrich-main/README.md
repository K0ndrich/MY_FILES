<h2 align="center">Hello, I'm Max K0ndrich 👋 </h2>


## 😗 About Me

  📝 **Hello! My name is Maxim Kondratenko and I am a beginner Python developer.
  I am passionate about creating simple but effective solutions in Python, learning various libraries and constantly improving my programming skills 💡. 
  My interests include writing server-side parts of websites, data analysis and web application development. 
  I am currently working on improving my knowledge in testing, working with APIs and code optimization 🚀.**

## 🏗 My Tech Stack


- **Pure Python 🐍**
- **OOP Python 🔧**
- **Framework Django 🌐**
- **Django REST / Rest API 💻**
- **Git / Git Hub / Git Actions 🐙**
- **SQLite / SQLite Studio 🛢️**
- **PostgreSQL / PgAdmin 💾**
- **Celery / Redis 🗄️**
- **Testing / Unittest 🛠️**
- **Docker / Docker-Compose / Docker Hub 🚢**
- **Linux / Ubuntu / Kali Linux 📂**

## ☎ My Contacts

1.  📬 [Gmail](123kondrich@gmail.com)                     **| 123kondrich@gmail.com**
2.  📁 [ProtonMail](kondrich@proton.me)                   **| kondrich@proton.me**
3.  💬 [Telegram](https://t.me/Kondrich1)                 **| https://t.me/Kondrich1**
4.  🐳 [Docker Hub](https://hub.docker.com/u/k0ndrich)    **| https://hub.docker.com/u/k0ndrich**
5.  📹 [Zoom](https://us05web.zoom.us/launch/chat?src=direct_chat_link&email=123kondrich%40gmail.com) **| https://us05web.zoom.us/launch/chat?src=direct_chat_link&email=123kondrich%40gmail.com**
6.  🎵 [SoundCloud](https://soundcloud.com/vw5m0mu9z4yh?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing)  **| https://on.soundcloud.com/4WirQEWdANGvuVue8**
