# Условные Операторы
# if Условие: Действие1 -> else: Действие2
x = 10
if x > 0:
    print("x > 0")
else:
    print("x < 0")

# if Условие1 : Действие1 -> elif Условие2: Действие2 -> else: Действие3
if x > 0:
    print("x > 0")  
elif x < 0:
    print("x < 0")
else:
    print("x == 0")

my_string = "hello world"