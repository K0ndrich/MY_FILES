# type() функция возвращает тип значения(или другого обьекта)
my_value = 5
type(my_value)

# str() фнукция преобразовывает значение в тип str
# <class 'str'>
my_var1 = 5.3
my_var2 = str(5.3)

# int() функция преобразовывает значение в тип int
# <class 'int'>
my_var1 = 5.3
my_var2 = int(5.3)

