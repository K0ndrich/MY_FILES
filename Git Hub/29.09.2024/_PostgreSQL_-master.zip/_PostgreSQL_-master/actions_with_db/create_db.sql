-- Создание Базы Данных (самой базы, а не таблици)
CREATE DATABASE my_name_db