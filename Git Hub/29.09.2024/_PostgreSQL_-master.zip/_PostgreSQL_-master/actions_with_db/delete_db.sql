-- Удаление Базы Данных (самой базы, а не таблици)
DROP DATABASE my_name_db